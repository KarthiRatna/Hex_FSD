"use strict";
var Employee = /** @class */ (function () {
    function Employee() {
    }
    return Employee;
}());
var emp = new Employee();
emp.name = "Karthika";
emp.age = 25;
emp.dateOfJoin = new Date(2019, 7, 22);
emp.salary = 10000;
emp.isMarried = false;
console.log(JSON.stringify(emp));
