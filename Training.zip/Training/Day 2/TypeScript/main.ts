import {sum,substract,multiply} from './file1';
import * as calc from './file1';

let a=5, b=4;
let total= calc.sum(a,b);
let diff= calc.substract(a,b);
let product= calc.multiply(a,b);

console.log("Add result is "+total);
console.log("difference result is "+diff);
console.log("product result is "+product);
