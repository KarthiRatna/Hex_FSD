"use strict";
exports.__esModule = true;
function sum(a, b) {
    return a + b;
}
exports.sum = sum;
function substract(a, b) {
    return a - b;
}
exports.substract = substract;
function multiply(a, b) {
    return a * b;
}
exports.multiply = multiply;
