interface IEmployee
{
    name: string;
    age: number;
    dateOfJoin: Date;
    salary: number;
    isMarried?: boolean;
}
class  Employee implements IEmployee
{
    name: string;
    age: number;
    dateOfJoin: Date;
    salary: number;
    isMarried?: boolean | undefined;


    constructor(){
        this.name="";
        this.age=0;
        this.dateOfJoin=new Date();
        this.salary=0;
        this.isMarried= false;
    }
}

var emp: Employee=new Employee();
emp.name="Karthika";
emp.age=25;
emp.dateOfJoin=new Date(2019,7,22);
emp.salary=10000;
emp.isMarried= false;

console.log(JSON.stringify(emp));