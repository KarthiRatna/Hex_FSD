export function sum( a:number,b:number):number{
    return a+b;
}

export function substract( a:number,b:number):number{
    return a-b;
}

export function multiply( a:number,b:number):number{
    return a*b;
}

