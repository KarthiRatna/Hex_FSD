import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'availability'
})
export class AvailabilityPipe implements PipeTransform {

 /*  transform(value: any, ...args: any[]): any {
    return null;
  } */

 /*  transform(qty: number): string {
    if(qty<=0)
    {
      return "Out of Stock";
    }
    else
    {
    return "In Stock";
    }
  } */

  transform(qty: number, emptymessage:string="Out of stock", availablemessage:string="In stock"): string {
    if(qty=0)
    {
      return emptymessage;
    }
    else
    {
    return availablemessage;
    }
  } 

}
