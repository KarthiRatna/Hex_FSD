import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
name:string;
today:Date;
isMarried:boolean=false;
size:number=18;
colorCode:string="#000000";
products:any[]=[
  {id:1, Fname:"Pizza", price:20 , quantity:2},
  {id:1, Fname:"burger", price:30 , quantity:0},
  {id:1, Fname:"Milk", price:10 , quantity:4.2121},
  {id:1, Fname:"coke", price:90 , quantity:56}
];
  constructor() {
    this.name="Karthika";
    this.today=new Date();
   }

  ngOnInit() {
  }
  toggleMarried(){
    this.isMarried=!this.isMarried;
  }

  updateFont(ctrl){
    console.log=ctrl;
    this.size=ctrl.value;
  }

  updateColor(ctrl){
    console.log=ctrl;
    this.colorCode=ctrl.value;
  }
}
