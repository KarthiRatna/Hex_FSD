export interface User
{
    username: string;
    password: string;
    email:string;
    recoveryQuestion:string;
    answer:string;
    fullname: string;
}