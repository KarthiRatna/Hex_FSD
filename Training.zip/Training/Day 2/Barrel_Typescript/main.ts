/* ********************WITHOUT BARREL******************

import {Employee} from './Models/employee';
import {EmployeeService} from './services/employee.service';

import {Product} from './Models/product';
import{ProductService} from './services/product.service';

import {User} from './Models/user';
import{UserService} from './services/user.service';
 */

 /* ********************WITH BARREL*******************/
import {ProductService,EmployeeService,UserService} from './services';
import {Product,User,Employee} from './Models';
 
let empsvc:EmployeeService=new EmployeeService();
let employees:Employee[]=empsvc.getEmployees();

let prodsvc:ProductService=new ProductService();
let products:Product[]=prodsvc.getProducts();


let usersvc:UserService=new UserService();
let users:User[]=usersvc.getUsers();
