export class UserService
{
    getUsers():any
    {

    }
    validateUser(username:string,password:string)
    {
        return false;
    }
}