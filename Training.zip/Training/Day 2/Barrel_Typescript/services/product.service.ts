export class ProductService
{
    getProducts():any
    {
//TODO: get all the list of products
    }
    getProductById(id:number)
    {
//search by id and return product
    }
}