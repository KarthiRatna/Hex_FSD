export class EmployeeService
{
    getEmployees():any
    {
        //TODO:get the list of employees
    }
    //any -> may or maynot return something
}