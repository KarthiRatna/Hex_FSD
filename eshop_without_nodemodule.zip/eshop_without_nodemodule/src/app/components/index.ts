export * from './home/home.component';
export * from './about/about.component';
export * from './detail/detail.component';
export * from './add-product/add-product.component';
export * from './register/register.component';