import { Component, OnInit } from '@angular/core';
import { ProductService } from 'src/app/services';
import { Product } from 'src/app/models';
import { ActivatedRoute } from '@angular/router';
import { FormControl, Validators } from '@angular/forms';


@Component({
  selector: 'detail',
  templateUrl: './detail.component.html',
  styleUrls: ['./detail.component.css']
})
export class DetailComponent implements OnInit {
    product:Product;
  constructor(private route : ActivatedRoute, private productsvc:ProductService) {
    let id= this.route.snapshot.params["id"];
    // this.product= this.productsvc.getProductById(id);
    this.productsvc.getProductById(id)
    .subscribe(
      res=>this.product=res,
      err=>console.log(err)
    )
   }



  ngOnInit() {
  }

}
