export class User {
    id?:number;
    User:string;
    password:string;
    fullname:string;
    email:string;
    mobile:string;
}
